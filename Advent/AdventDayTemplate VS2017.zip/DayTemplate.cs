﻿#region

using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Windows.Forms;
using Helper;
using static System.Console;

#endregion

namespace $safeprojectname$
{
    internal static class $safeprojectname$
    {
        private static void Main()
        {
            var input = Utilities.GetInput(typeof($safeprojectname$).Name);

            WriteLine($"First part answer: {input}");
            Clipboard.SetText(input);

            ReadKey();
        }
    }
}